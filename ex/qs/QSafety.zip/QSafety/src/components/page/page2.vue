<template>
    <div>
         <Header title="系统管理" text="操作日志"></Header>
    </div>
</template>

<script>
import Header from '../assembly/Header'
export default {
    components:{
        Header
    }
    
}
</script>

<style scoped>

</style>

